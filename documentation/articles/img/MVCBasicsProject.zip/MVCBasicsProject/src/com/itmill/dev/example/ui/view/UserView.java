package com.itmill.dev.example.ui.view;

import com.itmill.toolkit.ui.*;

public class UserView extends AbstractView {

	private VerticalLayout layout;

	/*
	 *  Styles the User View.
	 */
	public UserView() {

		setHeight("100%");

		layout = new VerticalLayout();
		setCompositionRoot(layout);

		layout.setMargin(true);
		layout.setHeight("100%");

		// setStyleName("view");

		Panel panel = new Panel("Thank you for logging in.");
		panel.setSizeFull();

		panel.addComponent(new Label(
						"Welcome to the user view. please select a channel from the menu."));
		layout.addComponent(panel);

	}

	/*
	 * Close method from AbstractView.
	 * 
	 * @see ui.AbstractView#close()
	 */
	protected void close() throws Exception {

	}

}
