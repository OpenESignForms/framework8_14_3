package com.itmill.dev.example.ui.view;

import com.itmill.toolkit.ui.CustomComponent;



public abstract class AbstractView extends CustomComponent {

	protected abstract void close() throws Exception;

}

