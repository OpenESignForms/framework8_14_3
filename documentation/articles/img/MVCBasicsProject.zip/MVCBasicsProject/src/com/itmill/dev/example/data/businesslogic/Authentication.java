package com.itmill.dev.example.data.businesslogic;

import com.itmill.dev.example.data.*;

public class Authentication {

	// Fake a database connection using com.itmill.dev.example.data.Database
	private Database DBConnection;

	public Authentication() {
		DBConnection = new Database();
	}

	/*
	 * Authenticates the user and returns the corresponding User object.
	 */
	public User Authenticate(String loginname, String password) {

		if ((loginname.equals("demo")) && (password.equals("demo"))) {
			return DBConnection.getUser(loginname);

		} else {
			return null;
		}

	}

}
